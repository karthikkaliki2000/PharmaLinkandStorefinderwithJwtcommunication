package com.CN.PharmaLink;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PharmaLinkApplication {

	public static void main(String[] args) {
		SpringApplication.run(PharmaLinkApplication.class, args);
	}

}
